package com.fitnesslot.service;

import com.fitnesslot.model.Cart;

public interface CartService {

    Cart getCartById(int cartId);

    void update(Cart cart);
}
