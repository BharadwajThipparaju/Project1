package com.fitnesslot.dao;

import com.fitnesslot.model.CustomerOrder;

public interface CustomerOrderDao {

    void addCustomerOrder(CustomerOrder customerOrder);
}
